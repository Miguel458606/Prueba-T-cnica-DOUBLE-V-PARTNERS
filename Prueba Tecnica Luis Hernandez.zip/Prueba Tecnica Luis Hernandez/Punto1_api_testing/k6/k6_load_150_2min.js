import http from 'k6/http';
import { check, sleep } from 'k6';

export let options = {
  vus: 150,
  duration: '2m',
  thresholds: {
    'http_req_duration': ['p(95)<5000'], // ejemplo de umbral
  },
};

const BASE = 'https://fakestoreapi.com';

export default function () {
  // 1) List all products
  const listRes = http.get(`${BASE}/products`);
  check(listRes, { 'list status 200': (r) => r.status === 200 });

  // 2) Add a new product
  const payload = JSON.stringify({
    title: "k6 Load Test Product",
    price: 9.99,
    description: "Test product created during load test",
    image: "https://i.imgur.com/test.png",
    category: "electronics"
  });
  const params = { headers: { 'Content-Type': 'application/json' } };
  const createRes = http.post(`${BASE}/products`, payload, params);
  check(createRes, { 'create status 200 or 201': (r) => r.status === 200 || r.status === 201 });

  sleep(1);
}
