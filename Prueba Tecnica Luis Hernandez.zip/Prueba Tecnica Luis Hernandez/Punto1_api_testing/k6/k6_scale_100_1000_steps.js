import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE = 'https://fakestoreapi.com';

const targets = [20, 40, 60, 80, 100]; // 100, +150 ... hasta 1000

export let options = {
  stages: targets.flatMap((t, i) => {
    // cada etapa dura 60s con target t
    return [{ duration: '60s', target: t }];
  }),
  thresholds: {
    'http_req_duration': ['p(95)<8000'],
  },
};

export default function () {
  // alternamos entre listar y crear
  const listRes = http.get(`${BASE}/products`);
  check(listRes, { 'list status 200': (r) => r.status === 200 });

  const payload = JSON.stringify({
    title: "k6 Scale Test Product",
    price: 19.90,
    description: "Scaling test item",
    image: "https://i.imgur.com/test2.png",
    category: "electronics"
  });
  const params = { headers: { 'Content-Type': 'application/json' } };
  const createRes = http.post(`${BASE}/products`, payload, params);
  check(createRes, { 'create status ok': (r) => r.status === 200 || r.status === 201 });

  sleep(1);
}
