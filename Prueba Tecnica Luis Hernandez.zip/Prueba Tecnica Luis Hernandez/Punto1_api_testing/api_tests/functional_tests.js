const axios = require('axios');
const { expect } = require('chai');
const BASE = 'https://fakestoreapi.com';

describe('Your Store - API Functional Tests', function() {
  this.timeout(20000);
  let createdId;

  it('1) GET /products/category/electronics -> must return array', async function() {
    const res = await axios.get(`${BASE}/products/category/electronics`);
    expect(res.status).to.equal(200);
    expect(res.data).to.be.an('array');
  });

  it('2) GET /products/{id} (id=1) -> must return product object with id 1', async function() {
    const res = await axios.get(`${BASE}/products/1`);
    expect(res.status).to.equal(200);
    expect(res.data).to.have.property('id', 1);
  });

  it('3) POST /products -> create a product and return id', async function() {
    const payload = {
      title: "QA Test Product - Alessandra",
      price: 123.45,
      description: "Created by automated functional test",
      image: "https://i.imgur.com/fake.png",
      category: "electronics"
    };
    const res = await axios.post(`${BASE}/products`, payload, { headers: { 'Content-Type': 'application/json' }});
    // fakestoreapi returns 200 for created resource
    expect([200,201]).to.include(res.status);
    expect(res.data).to.have.property('id');
    createdId = res.data.id;
    console.log('Created product id:', createdId);
  });

  it('4) PUT /products/{id} -> update image of created product', async function() {
    if (!createdId) this.skip();
    const update = { image: "https://i.imgur.com/updated.png" };
    const res = await axios.put(`${BASE}/products/${createdId}`, update, { headers: { 'Content-Type': 'application/json' }});
    expect([200,201]).to.include(res.status);
    expect(res.data).to.have.property('image');
    // depending on API behavior, this assertion may need ajuste localmente
    expect(res.data.image).to.be.a('string');
  });
});
