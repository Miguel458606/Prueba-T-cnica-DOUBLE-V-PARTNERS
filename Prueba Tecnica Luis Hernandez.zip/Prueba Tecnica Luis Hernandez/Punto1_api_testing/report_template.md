# Informe de Pruebas - Punto 1 (API Testing)

**Candidato:** Luis Miguel Hernández  
**Fecha de ejecución:** 14/09/2025  
**Entorno:** k6 Cloud (Grafana) – Región: Colón  

---

## Resumen ejecutivo
Se ejecutaron pruebas de API contra el endpoint `https://fakestoreapi.com` con el objetivo de validar comportamiento funcional y de rendimiento.  
Durante la prueba de carga con 100 usuarios virtuales simultáneos, el sistema mostró tiempos de respuesta consistentes (P95 ~44 ms) y un throughput aproximado de 175 req/s. Sin embargo, se identificó un alto número de respuestas con error **HTTP 403**, lo que indica posibles restricciones del API bajo escenarios de estrés.  

---

## Resultados técnicos

### 1. Prueba de carga (100 VUs, 2 minutos)
- **Solicitudes realizadas:** 22.8k  
- **RPS promedio:** ~175 req/s  
- **RPS máximo:** 200  
- **Tiempo de respuesta P95:** 44 ms  
- **Errores (HTTP 403):** 22.7k (~100%)  

### 2. Prueba de escalado (20 → 100 VUs, 60s por etapa)
Métricas mínimas a registrar:  
- **Solicitudes realizadas:** 28.2k  
- **RPS promedio:** ~91 req/s  
- **RPS máximo:** 186.67 req/s  
- **Tiempo de respuesta P95:** 43 ms  
- **Errores (HTTP 403):** 28.2k (~100%)  
---

## Observaciones
- El API respondió con **alta velocidad**, pero devolvió **403 Forbidden** en la mayoría de las solicitudes durante la carga.  
- Esto sugiere que la API pública no está diseñada para pruebas intensivas y podría tener limitaciones de seguridad o throttling.  
- Recomendación: solicitar un entorno de pruebas dedicado al proveedor del API o implementar mecanismos de autenticación válidos para escenarios de performance.  
- Aunque los tiempos de respuesta fueron bajos y estables, la totalidad de solicitudes resultaron en errores 403, lo que indica que la API pública no está habilitada para soportar pruebas de carga escaladas sin restricciones

---

## Conclusión
Las pruebas permitieron validar que el API mantiene buenos tiempos de respuesta bajo carga moderada, aunque la tasa de errores lo hace **no apto para escenarios productivos de alto volumen sin ajustes adicionales**.  
