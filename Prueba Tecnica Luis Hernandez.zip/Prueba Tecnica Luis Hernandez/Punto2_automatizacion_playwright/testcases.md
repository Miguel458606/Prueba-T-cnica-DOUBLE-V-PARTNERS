# Casos de prueba - Automatización (resumen)

1. Registro de usuario - Campos completos -> Se muestra confirmación de cuenta creada.
2. Inicio de sesión - Usuario/contraseña válidos -> Ingreso exitoso a My Account.
3. Restablecimiento de contraseña - Email registrado -> Mensaje de envío de correo.
4. Navegación a Laptops & Notebooks -> Mostrar todos.
5. Agregar MacBook Pro al carrito -> Mensaje/contador de carrito actualizado.
6. Buscar "Samsung Galaxy Tab" y agregar al carrito -> Producto agregado.
7. Eliminar MacBook Pro del carrito -> Producto removido.
8. Agregar otra unidad de tablet -> Cantidad actualizada.
9. Checkout completo hasta confirmación de orden -> Texto de confirmación presente.

Cada caso incluye validaciones de estado/elementos visibles. Los detalles paso a paso están implementados en `tests/flow.spec.js` usando POM.
