import { test, expect } from '@playwright/test';
import RegisterPage from '../pages/RegisterPage.js';
import LoginPage from '../pages/LoginPage.js';
import PasswordResetPage from '../pages/PasswordResetPage.js';
import LaptopsPage from '../pages/LaptopsPage.js';
import CartPage from '../pages/CartPage.js';
import CheckoutPage from '../pages/CheckoutPage.js';

function randomEmail() { return `alessandra.paredes+${Date.now()}@example.com`; }

test.describe('OpenCart full user flow - automated', () => {
  test('Complete register, login, reset password, add/remove products and checkout', async ({ page }) => {
    const registerPage = new RegisterPage(page);
    const loginPage = new LoginPage(page);
    const pwdPage = new PasswordResetPage(page);
    const laptops = new LaptopsPage(page);
    const cart = new CartPage(page);
    const checkout = new CheckoutPage(page);

    // Datos de prueba
    const user = {
      firstName: 'Alessandra',
      lastName: 'Paredes',
      email: randomEmail(),
      telephone: '3001234567',
      password: 'Passw0rd!',
      address: 'Calle Falsa 123',
      city: 'Bogota',
      postcode: '110111'
    };

    // 1. Registro
    await registerPage.goto();
    await registerPage.register(user);
    // Validar que registro completó (mensaje de éxito)
    await expect(page.locator('h1, text=Your Account Has Been Created, text=Congratulations')).toHaveCountGreaterThan(0);

    // 2. Logout (si aplica) y login
    await page.locator('text=My Account').click();
    await page.locator('text=Logout').click().catch(()=>{});
    await loginPage.goto();
    await loginPage.login(user.email, user.password);
    // Validar login exitoso
    await expect(page.locator('text=My Account')).toHaveCountGreaterThan(0);

    // 3. Restablecimiento de contraseña (flujo)
    await pwdPage.goto();
    await pwdPage.reset(user.email);
    // Esperar confirmación
    await expect(page.locator('text=An email with a confirmation link has been sent')).toHaveCountGreaterThan(0).catch(()=>{});

    // 4. Ir a Laptops & Notebooks -> Show all
    await laptops.goToLaptops();
    // 5. Agregar MacBook Pro
    await laptops.addMacBookProToCart();
    // 6. Buscar Samsung Galaxy tablet y agregar al carrito
    await laptops.searchAndAddTablet('Samsung Galaxy Tab');
    // 7. Abrir carrito y eliminar MacBook Pro
    await cart.openCart();
    await cart.removeProductByName('MacBook Pro');
    // 8. Agregar otra unidad (ya agregada la tablet previamente) -> si es necesario volver a agregar
    await laptops.searchAndAddTablet('Samsung Galaxy Tab');
    // 9. Completar proceso de compra
    await checkout.proceedToCheckoutAndComplete(user);

    // Validar confirmación de la orden (texto genérico)
    await expect(page.locator('text=Your order has been placed, text=Order Confirmation, h1:has-text("Your Order")')).toHaveCountGreaterThan(0).catch(()=>{});

  });
});
