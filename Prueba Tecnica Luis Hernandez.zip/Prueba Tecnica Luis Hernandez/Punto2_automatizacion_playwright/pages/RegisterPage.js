export default class RegisterPage {
  constructor(page) {
    this.page = page;
    this.firstName = page.locator('input[name="firstname"]');
    this.lastName = page.locator('input[name="lastname"]');
    this.email = page.locator('input[name="email"]');
    this.telephone = page.locator('input[name="telephone"]');
    this.password = page.locator('input[name="password"]');
    this.confirm = page.locator('input[name="confirm"]');
    this.privacy = page.locator('input[name="agree"], text=Privacy Policy');
    this.continueBtn = page.locator('input[value="Continue"], button:has-text("Continue")');
  }

  async goto() {
    await this.page.goto('https://opencart.abstracta.us/');
    await this.page.locator('text=My Account').click();
    await this.page.locator('text=Register').click();
  }

  async register(user) {
    await this.firstName.fill(user.firstName);
    await this.lastName.fill(user.lastName);
    await this.email.fill(user.email);
    await this.telephone.fill(user.telephone);
    await this.password.fill(user.password);
    await this.confirm.fill(user.password);
    // aceptamos política de privacidad si existe checkbox
    try { await this.privacy.check({ timeout: 2000 }); } catch(e){}
    await this.continueBtn.click();
  }
}
