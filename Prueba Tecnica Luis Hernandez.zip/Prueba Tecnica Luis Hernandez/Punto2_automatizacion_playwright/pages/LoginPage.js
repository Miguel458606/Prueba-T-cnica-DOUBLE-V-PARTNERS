export default class LoginPage {
  constructor(page) {
    this.page = page;
    this.email = page.locator('input[name="email"]');
    this.password = page.locator('input[name="password"]');
    this.loginBtn = page.locator('input[value="Login"], button:has-text("Login")');
  }

  async goto() {
    await this.page.goto('https://opencart.abstracta.us/');
    await this.page.locator('text=My Account').click();
    await this.page.locator('text=Login').click();
  }

  async login(email, password) {
    await this.email.fill(email);
    await this.password.fill(password);
    await this.loginBtn.click();
  }
}
