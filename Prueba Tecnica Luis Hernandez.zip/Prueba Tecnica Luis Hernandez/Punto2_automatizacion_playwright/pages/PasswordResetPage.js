export default class PasswordResetPage {
  constructor(page) {
    this.page = page;
    this.email = page.locator('input[name="email"]');
    this.continueBtn = page.locator('input[value="Continue"], button:has-text("Continue")');
  }

  async goto() {
    await this.page.goto('https://opencart.abstracta.us/');
    await this.page.locator('text=My Account').click();
    await this.page.locator('text=Login').click();
    await this.page.locator('text=Forgotten Password').click();
  }

  async reset(email) {
    await this.email.fill(email);
    await this.continueBtn.click();
  }
}
