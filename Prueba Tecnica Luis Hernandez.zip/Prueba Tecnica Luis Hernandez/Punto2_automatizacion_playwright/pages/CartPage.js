export default class CartPage {
  constructor(page) {
    this.page = page;
  }

  async openCart() {
    await this.page.locator('#cart').click();
    // Esperar dropdown
    await this.page.waitForTimeout(1000);
  }

  async removeProductByName(name) {
    // En el carrito, buscar producto y clicar remove (selector genérico)
    const removeBtn = this.page.locator(`.table .text-left:has-text("${name}")`).locator('..').locator('button[title="Remove"], button:has-text("Remove")');
    try { await removeBtn.first().click(); } catch(e) { /* si falla, intentarlo de otra forma */ }
  }
}
