export default class CheckoutPage {
  constructor(page) {
    this.page = page;
  }

  async proceedToCheckoutAndComplete(dummyUser) {
    await this.page.goto('https://opencart.abstracta.us/index.php?route=checkout/cart');
    // Click Checkout
    await this.page.locator('a:has-text("Checkout")').click();

    // Intentaremos completar checkout como Guest si disponible
    try {
      await this.page.locator('input[name="account"][value="guest"]').check({ timeout: 2000 });
    } catch (e) {}

    // Rellenar datos (puede variar según la tienda)
    await this.page.locator('input[name="firstname"]').fill(dummyUser.firstName);
    await this.page.locator('input[name="lastname"]').fill(dummyUser.lastName);
    await this.page.locator('input[name="email"]').fill(dummyUser.email);
    await this.page.locator('input[name="telephone"]').fill(dummyUser.telephone);
    await this.page.locator('input[name="address_1"]').fill(dummyUser.address);
    await this.page.locator('input[name="city"]').fill(dummyUser.city);
    await this.page.locator('input[name="postcode"]').fill(dummyUser.postcode);

    // Country / Region selectors (opencart sometimes requiere selección)
    try {
      await this.page.selectOption('select[name="country_id"]', '17'); // example: 17 = Colombia (ajustar localmente)
    } catch (e) {}
    try {
      await this.page.selectOption('select[name="zone_id"]', '1');
    } catch (e) {}

    // Continuar por pasos: Shipping method, Payment method
    // Aceptar términos si existen
    try { await this.page.locator('input[name="agree"]').check({ timeout: 2000 }); } catch(e){}

    // Click confirmar (selector genérico)
    await this.page.locator('button:has-text("Continue"), input[value="Continue"]').last().click();

    // Esperar confirmación
    await this.page.waitForTimeout(3000);
  }
}
