export default class LaptopsPage {
  constructor(page) {
    this.page = page;
  }

  async goToLaptops() {
    await this.page.goto('https://opencart.abstracta.us/');
    // Abrir menú Laptops & Notebooks -> Show All Laptops & Notebooks
    await this.page.locator('text=Laptops & Notebooks').hover();
    await this.page.locator('text=Show All Laptops & Notebooks').click();
  }

  async addMacBookProToCart() {
    // busca producto por texto y clic en Add to Cart cerca del producto
    await this.page.locator('a:has-text("MacBook Pro")').first().click();
    // click Add to cart
    await this.page.locator('button#button-cart, button:has-text("Add to Cart")').click();
  }

  async searchAndAddTablet(productName) {
    await this.page.locator('input[name="search"]').fill(productName);
    await this.page.locator('button[type="button"]:has-text("Search"), button:has-text("Search")').click();
    // Dar click en Add to Cart del primer producto encontrado
    await this.page.locator('button:has-text("Add to Cart")').first().click();
  }
}
